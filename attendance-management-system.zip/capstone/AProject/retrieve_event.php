<?php


$conn= mysqli_connect("localhost","root","","attendance-monitoring");


$result=array();
$result['event']=array();
$select = "SELECT * FROM event";
$response = mysqli_query($conn,$select);

while($row=mysqli_fetch_array($response)){
	$index['event_id'] = $row[1];
	$index['event_name'] = $row[2];
	$index['event_date'] = $row[3];
	$index['event_time'] = $row[4];
	$index['event_time_end'] = $row[5];
	$index['event_speaker'] = $row[6];
	$index['event_link'] = $row[7];

	array_push($result['event'],$index);

}
$result['success']="1";
echo json_encode($result);



?>