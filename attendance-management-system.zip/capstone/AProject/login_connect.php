<?php

$conn= mysqli_connect("localhost","root","","attendance-monitoring");

$username=$_POST["name"];
$password=$_POST["password"];



$admin= "SELECT admin_username, admin_password FROM admin_account WHERE admin_username LIKE '$username' AND admin_password LIKE '$password' LIMIT 1";
	$instructor= "SELECT employee_email , employee_password FROM instructor_account WHERE employee_email LIKE '$username' AND employee_password LIKE '$password' LIMIT 1";
	$e_student ="SELECT student_email, student_password FROM student_account WHERE student_email LIKE '$username' AND student_password LIKE '$password' LIMIT 1";


$result = mysqli_query($conn,$instructor);
$admin_result = mysqli_query($conn,$admin);
$student_result = mysqli_query($conn,$e_student);
if(mysqli_num_rows($result)>0){
	echo "LOGIN SUCCESS";
}else if (mysqli_num_rows($student_result)>0) {
	echo "Login Success Student";
} else {
	echo "LOGIN FAILED";
}






?>