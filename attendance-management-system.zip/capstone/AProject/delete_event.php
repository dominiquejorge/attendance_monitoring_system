<?php

$conn= mysqli_connect("localhost","root","","attendance-monitoring");

$id=$_POST['id'];

$sql="DELETE FROM event WHERE event_id='$id'";
$result=mysqli_query($conn,$sql);

if ($result) {
	echo "Data Deleted";
} else {
	echo "Failed";
}




?>