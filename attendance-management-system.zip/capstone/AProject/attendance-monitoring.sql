-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 08, 2021 at 11:28 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance-monitoring`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_account`
--

CREATE TABLE `admin_account` (
  `id_admin` int(10) NOT NULL,
  `admin_fname` varchar(50) NOT NULL,
  `admin_lname` varchar(50) NOT NULL,
  `admin_username` varchar(50) NOT NULL,
  `admin_password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_account`
--

INSERT INTO `admin_account` (`id_admin`, `admin_fname`, `admin_lname`, `admin_username`, `admin_password`) VALUES
(1, 'admin', 'admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `choices`
--

CREATE TABLE `choices` (
  `choices_id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT 0,
  `choices_text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `choices`
--

INSERT INTO `choices` (`choices_id`, `quiz_id`, `question_id`, `is_correct`, `choices_text`) VALUES
(218, 1, 1, 0, 'sdas'),
(219, 1, 1, 1, 'asdas'),
(220, 1, 1, 0, 'asdas'),
(221, 1, 1, 0, 'asdas'),
(230, 2, 1, 1, 'HELLO'),
(231, 2, 1, 0, 'HI'),
(232, 2, 1, 0, 'WORLDs'),
(233, 2, 1, 0, 'NEW'),
(234, 2, 2, 0, 'Trial 1'),
(235, 2, 2, 0, 'Trial 2'),
(236, 2, 2, 0, 'Trial 3 '),
(237, 2, 2, 1, 'Trial 4');

-- --------------------------------------------------------

--
-- Table structure for table `enrolled_student`
--

CREATE TABLE `enrolled_student` (
  `id` int(11) NOT NULL,
  `e_student_id` varchar(15) NOT NULL,
  `e_student_name` varchar(30) NOT NULL,
  `e_student_email` varchar(30) NOT NULL,
  `e_student_block` varchar(10) NOT NULL,
  `e_student_webinar_time` int(10) NOT NULL,
  `e_student_password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `enrolled_student`
--

INSERT INTO `enrolled_student` (`id`, `e_student_id`, `e_student_name`, `e_student_email`, `e_student_block`, `e_student_webinar_time`, `e_student_password`) VALUES
(1, '12345', 'Dominique Jorge', 'doli.jorge@up.p', 'Block 5', 30, '12345'),
(2, '56789', 'Jorge Dominique', 'doli.jorge@up.phinma.eud.ph', 'Block 5', 30, '1');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `event_name` varchar(20) NOT NULL,
  `event_date` date NOT NULL,
  `event_time` varchar(15) NOT NULL,
  `event_time_end` varchar(15) NOT NULL,
  `event_speaker` varchar(20) NOT NULL,
  `event_link` varchar(100) NOT NULL,
  `event_time_total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `event_id`, `event_name`, `event_date`, `event_time`, `event_time_end`, `event_speaker`, `event_link`, `event_time_total`) VALUES
(1, 3, 'Webinar 2', '2020-12-18', '09:00', '23:00', 'Dominique', 'https://meet.google.com/wfe-akhf-rza', 14),
(2, 2, 'Webinar', '2020-12-16', '09:00', '10:00', 'Dominique', 'http://localhost/Capstone%20Project/instructor_dashboard.php', 1);

-- --------------------------------------------------------

--
-- Table structure for table `instructor_account`
--

CREATE TABLE `instructor_account` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `employee_fname` varchar(30) NOT NULL,
  `employee_lname` varchar(30) NOT NULL,
  `employee_email` varchar(50) NOT NULL,
  `employee_username` varchar(20) NOT NULL,
  `employee_password` varchar(50) NOT NULL,
  `date_created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `instructor_account`
--

INSERT INTO `instructor_account` (`id`, `employee_id`, `employee_fname`, `employee_lname`, `employee_email`, `employee_username`, `employee_password`, `date_created`) VALUES
(6, 123456, 'Dominique', 'Jorge', 'dom@gmail.com', 'Jorge', '123456', '2020-11-15');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `question_text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`id`, `question_id`, `quiz_id`, `question_text`) VALUES
(1, 1, 1, 'WORLD'),
(2, 1, 2, 'HELLO WORLD'),
(3, 2, 2, 'Trial Question');

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `quiz_id` int(11) NOT NULL,
  `quiz_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`quiz_id`, `quiz_name`) VALUES
(1, 'First Quiz'),
(2, 'Quiz 2');

-- --------------------------------------------------------

--
-- Table structure for table `student_account`
--

CREATE TABLE `student_account` (
  `id` int(11) NOT NULL,
  `student_id` varchar(13) NOT NULL,
  `student_fname` varchar(30) NOT NULL,
  `student_lname` varchar(30) NOT NULL,
  `student_email` varchar(50) NOT NULL,
  `student_password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_account`
--

INSERT INTO `student_account` (`id`, `student_id`, `student_fname`, `student_lname`, `student_email`, `student_password`) VALUES
(2, '03-1617-01441', 'Dominique', 'Jorge', 'doli.jorge@up.phinma.edu.ph', '12345'),
(8, '56789', 'Jorge', 'Dominique', 'doli.jorge@up.phinma.edu.ph', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_account`
--
ALTER TABLE `admin_account`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `choices`
--
ALTER TABLE `choices`
  ADD PRIMARY KEY (`choices_id`);

--
-- Indexes for table `enrolled_student`
--
ALTER TABLE `enrolled_student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instructor_account`
--
ALTER TABLE `instructor_account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`quiz_id`);

--
-- Indexes for table `student_account`
--
ALTER TABLE `student_account`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_account`
--
ALTER TABLE `admin_account`
  MODIFY `id_admin` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `choices`
--
ALTER TABLE `choices`
  MODIFY `choices_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=238;

--
-- AUTO_INCREMENT for table `enrolled_student`
--
ALTER TABLE `enrolled_student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `instructor_account`
--
ALTER TABLE `instructor_account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `student_account`
--
ALTER TABLE `student_account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
