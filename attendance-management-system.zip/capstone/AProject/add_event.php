<?php


$conn= mysqli_connect("localhost","root","","attendance-monitoring");



		$event_id = $_POST['event_id'];
		$event_name = $_POST['event_name'];
		$event_date= $_POST['event_date'];
		$event_time= $_POST['event_time'];
		$event_time_end= $_POST['event_time_end'];

		$event_speaker= $_POST['event_speaker'];
		$event_link= $_POST['event_link'];


		$ins_query = "INSERT INTO event (event_id, event_name, event_date, event_time,event_time_end, event_speaker, event_link) VALUES ('$event_id','$event_name','$event_date','$event_time','$event_time_end','$event_speaker','$event_link')";

		$insert_result=mysqli_query($conn,$ins_query);

		if ($insert_result) {
			echo "Data Inserted";
		} else {
			echo "Failed";
		}
		
		
?>