<?php
$conn= mysqli_connect("localhost","root","","attendance-monitoring");
// if ($_SERVER['REQUEST_METHOD']=='POST'){

// 	$student_id = $_POST['regid'];
// 	$fname = $_POST['fname'];
// 	$lname = $_POST['lname'];
// 	$email = $_POST['email'];
// 	$password = $_POST['password'];


// 	$INSERT = "INSERT INTO student_account (student_id,student_fname,student_lname,student_email,student_password ) VALUES
// 				('$student_id','$fname','$lname','$email','$password')";
// 	if (mysqli_query($conn,$INSERT)) 		
// 		$result["success"]="1";
// 		$result["message"]="success";

// 		echo json_encode($result);
		

// 	}else{
// 		$result["success"]="0";
// 		$result["message"]="error";

// 		echo json_encode($result);
		
// 	}
// }

	$student_id = $_POST['regid'];
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$password = $_POST['password'];


	$INSERT = "INSERT INTO student_account (student_id,student_fname,student_lname,student_email,student_password ) VALUES
				('$student_id','$fname','$lname','$email','$password')";

	if ($conn->query($INSERT)=== TRUE) {
		echo "Registration Success! ";
	}else{
		echo "Registration Failed".$INSERT."<br>".$conn->error();
	}

	$conn->close();
?>