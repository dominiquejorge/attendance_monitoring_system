package com.example.capstone;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class EventAdapter extends ArrayAdapter<Event> {

    Context context;
    List<Event> arrayListEvent;


    public EventAdapter(@NonNull Context context, List<Event> arrayListEvent) {
        super(context, R.layout.custom_list_item_event,arrayListEvent);

        this.context = context;
        this.arrayListEvent = arrayListEvent;


    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_list_item_event,null,true);

        TextView tv_event_id =view.findViewById(R.id.txt_event_id);
        TextView tv_event_name =view.findViewById(R.id.txt_event_name);

        tv_event_id.setText(arrayListEvent.get(position).getEvent_id());
        tv_event_name.setText(arrayListEvent.get(position).getEvent_name());

        return view;
    }
}
