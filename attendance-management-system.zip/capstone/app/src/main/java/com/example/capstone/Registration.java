package com.example.capstone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Registration extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    EditText regid,fname,lname,email,password,c_password;
    Spinner yearlevel, block;
    TextView loginpage;
    Button btnreg;
    ProgressBar loading;
    String sregid,sfname,slname,semail,spassword;
    //private static String URL_REGIST ="http://192.168.1.11/AProject/registration.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration);

        regid = findViewById(R.id.regid);
        fname = findViewById(R.id.fname);
        lname = findViewById(R.id.lname);
        email = findViewById(R.id.regEmail);
        password = findViewById(R.id.etpassword);
        c_password =findViewById(R.id.etcpassword);
        yearlevel = findViewById(R.id.yearlevel);
        block = findViewById(R.id.block);
        loginpage = findViewById(R.id.loginpage);
        btnreg = findViewById(R.id.btnregister);
        loading = findViewById(R.id.loading);
        populateSpinnerYearlevel();
        populateSpinnerBlock();


        btnreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OnReg();

                Intent intent = new Intent(Registration.this, Registration.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });

        loginpage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Registration.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });
    }

    private void OnReg(){

        String sregid = this.regid.getText().toString();
        String sfname = this.fname.getText().toString();
        String slname = this.lname.getText().toString();
        String semail = this.email.getText().toString();
        String spassword = this.password.getText().toString();
        String c_password = this.c_password.getText().toString();
        String yearlevel = this.yearlevel.toString();
        String block = this.block.toString();
        String type ="register";

        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        backgroundWorker.execute(type,sregid,sfname,slname,semail,spassword);

    }
//    private void Regist(){
//        loading.setVisibility(View.VISIBLE);
//        btnreg.setVisibility(View.GONE);
//
//        final String regid = this.regid.getText().toString().trim();
//        final String fname = this.fname.getText().toString().trim();
//        final String lname = this.lname.getText().toString().trim();
//        final String email = this.email.getText().toString().trim();
//        final String password = this.password.getText().toString().trim();
//        final String c_password = this.c_password.getText().toString().trim();
//        final String yearlevel = this.yearlevel.toString().trim();
//        final String block = this.block.toString().trim();
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_REGIST, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//            try{
//                JSONObject jsonObject = new JSONObject(response);
//                String success = jsonObject.getString("success");
//
//
//                if(success.equals("1")){
//                    Toast.makeText(Registration.this,"Registration Success", Toast.LENGTH_SHORT).show();
//                }
//
//            } catch (JSONException e) {
//                e.printStackTrace();
//                Toast.makeText(Registration.this,"Registration Failed "+ e.toString(), Toast.LENGTH_SHORT).show();
//                loading.setVisibility(View.GONE);
//                btnreg.setVisibility(View.VISIBLE);
//            }
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                Toast.makeText(Registration.this,"Registration Failed "+ error.toString(), Toast.LENGTH_SHORT).show();
//                loading.setVisibility(View.GONE);
//                btnreg.setVisibility(View.VISIBLE);
//            }
//        })
//        {
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//
//                Map<String, String> params = new HashMap<>();
//                params.put("regid",regid);
//                params.put("fname",fname);
//                params.put("lname",lname);
//                params.put("email",email);
//                params.put("password",password);
//
//
//
//                return params;
//            }
//        };
//
//        RequestQueue requestQueue = Volley.newRequestQueue(this);
//        requestQueue.add(stringRequest);
//
//
//    }

    private void populateSpinnerBlock() {
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,R.array.block,android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_item);
        block.setAdapter(adapter2);
        block.setOnItemSelectedListener(this);
    }


    private void populateSpinnerYearlevel() {
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this,R.array.yearlevel,android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_item);
        yearlevel.setAdapter(adapter1);
        yearlevel.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String text = adapterView.getItemAtPosition(i).toString();
        //Toast.makeText(adapterView.getContext(), text, Toast.LENGTH_SHORT).show();
        ((TextView) adapterView.getChildAt(0)).setTextColor(Color.WHITE);
        ((TextView) adapterView.getChildAt(0)).setTextSize(12);
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
