package com.example.capstone;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class add_event extends AppCompatActivity {

    EditText event_id,event_name,event_speaker,event_link,event_date, event_time,event_time_end;
    DatePickerDialog.OnDateSetListener setListener;
    TimePickerDialog timePickerDialog;
    Button addevent;
    int currentHour;
    int currentMinute;
    String amPm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_event);

        event_id=findViewById(R.id.event_id);
        event_name=findViewById(R.id.event_name);
        event_speaker=findViewById(R.id.event_speaker);
        event_link=findViewById(R.id.event_link);
        event_date=findViewById(R.id.event_date);
        event_time=findViewById(R.id.event_time);
        event_time_end=findViewById(R.id.event_time_end);
        addevent=findViewById(R.id.btn_add_event);



        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);
        currentHour = calendar.get(Calendar.HOUR_OF_DAY);
        currentMinute = calendar.get(Calendar.MINUTE);


        addevent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insert_data();
            }
        });

        event_time_end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timePickerDialog = new TimePickerDialog(add_event.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                        if (hourOfDay >=12){
                            amPm = "PM";
                        }else{
                            amPm = "AM";
                        }
                        event_time_end.setText(String.format("%02d:%02d",hourOfDay,minutes));

//                        event_time.setText(hourOfDay+":"+minutes+ amPm);
                    }
                },currentHour, currentMinute, false);
                timePickerDialog.show();
            }
        });

        event_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timePickerDialog = new TimePickerDialog(add_event.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                        if (hourOfDay >=12){
                            amPm = "PM";
                        }else{
                            amPm = "AM";
                        }
                        event_time.setText(String.format("%02d:%02d",hourOfDay,minutes));

//                        event_time.setText(hourOfDay+":"+minutes+ amPm);
                    }
                },currentHour, currentMinute, false);
                      timePickerDialog.show();
            }
        });

        event_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        add_event.this,android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        setListener,year,month,day);
                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();
            }
        });

        setListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                month = month+1;
                String date = day+"/"+"/"+year;
                event_date.setText(date);


            }
        };
        event_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        add_event.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                        month = month+1;
                        String date = day+"/"+month+"/"+year;
                        event_date.setText(date);
                    }
                },year,month,day);
                datePickerDialog.show();

            }
        });
    }

    private void insert_data(){
        final String event_id = this.event_id.getText().toString().trim();
        final String event_name = this.event_name.getText().toString().trim();
        final String event_date = this.event_date.getText().toString().trim();
        final String event_time = this.event_time.getText().toString().trim();
        final String event_time_end = this.event_time_end.getText().toString().trim();
        final String event_speaker = this.event_speaker.getText().toString().trim();
        final String event_link = this.event_link.getText().toString().trim();

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading");

        if (event_id.isEmpty()){
            Toast.makeText(this,"Enter Event ID",Toast.LENGTH_SHORT);
            return;
        }
        else if (event_name.isEmpty()){
            Toast.makeText(this,"Enter Event Name",Toast.LENGTH_SHORT);
            return;
        }
        else if (event_date.isEmpty()){
            Toast.makeText(this,"Enter Event Date",Toast.LENGTH_SHORT);
            return;
        }
        else if (event_time.isEmpty()){
            Toast.makeText(this,"Enter Event Time",Toast.LENGTH_SHORT);
            return;
        }
        else if (event_time_end.isEmpty()){
            Toast.makeText(this,"Enter Event Time End",Toast.LENGTH_SHORT);
            return;
        }
        else if (event_speaker.isEmpty()){
            Toast.makeText(this,"Enter Event Speaker",Toast.LENGTH_SHORT);
            return;
        }
        else if (event_link.isEmpty()){
            Toast.makeText(this,"Enter Event Link",Toast.LENGTH_SHORT);
            return;
        }else{
            progressDialog.show();
            StringRequest request = new StringRequest(Request.Method.POST, "http://192.168.1.11/AProject/add_event.php", new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    if (response.equalsIgnoreCase("Data Inserted")){
                        Toast.makeText(add_event.this,"Data Inserted",Toast.LENGTH_SHORT);
                        progressDialog.dismiss();
                        Intent intent = new Intent(add_event.this, instructor_home.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);

                    }else{
                        Toast.makeText(add_event.this,response,Toast.LENGTH_SHORT);
                        progressDialog.dismiss();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(add_event.this,error.getMessage(),Toast.LENGTH_SHORT);
                    progressDialog.dismiss();
                }
            }
            ){
                @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                    Map<String,String> params = new HashMap<String, String>();
                    params.put("event_id",event_id);
                    params.put("event_name",event_name);
                    params.put("event_date",event_date);
                    params.put("event_time",event_time);
                    params.put("event_time_end",event_time_end);
                    params.put("event_speaker",event_speaker);
                    params.put("event_link",event_link);





                return params;
            }
        };
            RequestQueue requestQueue = Volley.newRequestQueue(add_event.this);
            requestQueue.add(request);
            };
        }
    }

