package com.example.capstone;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText Email;
    private EditText Password;
    private TextView Info;
    private Button Login;
    private TextView userRegistration;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Email = (EditText) findViewById(R.id.editName);
        Password = (EditText) findViewById(R.id.InPW);
        Info = (TextView) findViewById(R.id.lowinfo);
        Login = (Button) findViewById(R.id.btnlogin);
        userRegistration = (TextView) findViewById(R.id.Registerpage);



        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validates()) {
                    check();
                    Email.getText().clear();
                    Password.getText().clear();

                }

            }

        });

        userRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Registration.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });
    }

    private Boolean validates() {
        Boolean result = false;

        String name = Email.getText().toString();
        String password = Password.getText().toString();
        String type = "login";
        //String Cpassword=CPW.getText().toString();
        //String email=Email.getText().toString();





        if (name.isEmpty() && password.isEmpty()) {
            Toast.makeText(this, "Please Enter All Details", Toast.LENGTH_SHORT).show();
        }else if (name.isEmpty()){
            Toast.makeText(this, "Please Enter Email", Toast.LENGTH_SHORT).show();
        }else if (password.isEmpty()){
            Toast.makeText(this, "Please Enter Password", Toast.LENGTH_SHORT).show();
        } else {

            result = true;

        }

        return result;

    }

    public void check(){
        String name = Email.getText().toString();
        String password = Password.getText().toString();
        String type = "login";
        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        backgroundWorker.execute(type,name,password);
    }
}
