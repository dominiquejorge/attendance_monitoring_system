package com.example.capstone;

public class Event {
    private String event_id,event_name,event_date, event_time,event_time_end,event_speaker,event_link;

    public Event() {

    }
    public Event(String event_id, String event_name, String event_speaker, String event_link, String event_date, String event_time, String event_time_end) {
        this.event_id = event_id;
        this.event_name = event_name;
        this.event_date = event_date;
        this.event_time = event_time;
        this.event_time_end = event_time_end;
        this.event_speaker = event_speaker;
        this.event_link = event_link;

    }


    public String getEvent_id() {
        return event_id;
    }

    public void setEvent_id(String event_id) {
        this.event_id = event_id;
    }

    public String getEvent_name() {
        return event_name;
    }

    public void setEvent_name(String event_name) {
        this.event_name = event_name;
    }

    public String getEvent_date() {
        return event_date;
    }

    public void setEvent_date(String event_date) {
        this.event_date = event_date;
    }

    public String getEvent_time() {
        return event_time;
    }

    public void setEvent_time(String event_time) {
        this.event_time = event_time;
    }

    public String getEvent_time_end() {
        return event_time_end;
    }

    public void setEvent_time_end(String event_time_end) {
        this.event_time_end = event_time_end;
    }

    public String getEvent_speaker() {
        return event_speaker;
    }

    public void setEvent_speaker(String event_speaker) {
        this.event_speaker = event_speaker;
    }

    public String getEvent_link() {
        return event_link;
    }

    public void setEvent_link(String event_link) {
        this.event_link = event_link;
    }
}
