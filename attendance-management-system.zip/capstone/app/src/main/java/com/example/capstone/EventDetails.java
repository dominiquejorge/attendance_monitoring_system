package com.example.capstone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class EventDetails extends AppCompatActivity {

    TextView tve_id,tve_name,tve_date,tve_time,tve_time_end,tve_speaker,tve_link;
    int position;
    Button btn_home;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_details);

        tve_id = findViewById(R.id.txteventid);
        tve_name = findViewById(R.id.txteventname);
        tve_date = findViewById(R.id.txteventdate);
        tve_time=findViewById(R.id.txteventtime);
        tve_time_end=findViewById(R.id.txteventtimeend);
        tve_speaker=findViewById(R.id.txteventspeaker);
        tve_link=findViewById(R.id.txteventlink);
        btn_home=findViewById(R.id.btn_home);



        Intent intent =getIntent();
        position=intent.getExtras().getInt("position");

        tve_id.setText("Event ID: "+instructor_home.eventArrayList.get(position).getEvent_id());
        tve_id.setText("Event ID: "+instructor_home.eventArrayList.get(position).getEvent_id());
        tve_name.setText("Event Name: "+instructor_home.eventArrayList.get(position).getEvent_name());
        tve_date.setText("Event Date: "+instructor_home.eventArrayList.get(position).getEvent_speaker());
        tve_time.setText("Event Time Start: "+instructor_home.eventArrayList.get(position).getEvent_link());
        tve_time_end.setText("Event Time End: "+instructor_home.eventArrayList.get(position).getEvent_date());
        tve_speaker.setText("Event Speaker: "+instructor_home.eventArrayList.get(position).getEvent_time());
        tve_link.setText("Event Link: "+instructor_home.eventArrayList.get(position).getEvent_time_end());


        btn_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(EventDetails.this,instructor_home.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });
    }
}
